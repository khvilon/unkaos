
    
      
      export const openaiConfig = {
        key: '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'
      };
      
      export const restConfig = {
        port: 5010
      };
