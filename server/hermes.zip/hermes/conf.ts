
    export const emailConfig = {
        transport: {
            service: "yandex",
            auth: {
                user: "info@unkaos.ru",
                pass: "uixfypcrqoquclbr"
            }
        },
        from: '"Unkaos" <info@unkaos.ru>',
      };
      
      export const discordConfig = {
        token: 'MTA2ODEyMTc4NDU2NzcyNjE5MQ.GDCUQ-.pgsWcl11AN0accIgNKCwvXRZ-EKktg5Qul0DhQ',
      };
      
      export const telegramConfig = {
        token: '5977033877:AAHAxz-zwqYtpbq_uBnkVj89yfO30B8S9IM',
      };

    
      export const slackConfig = {
        token: 'YOUR_SLACK_TOKEN',
      };
      
      export const whatsappConfig = {
        phoneNumber: 'YOUR_PHONE_NUMBER',
        qrCode: 'YOUR_QR_CODE',
      };

      export const restConfig = {
        port: 5009
      };

      export const config = {
        base_url: 'https://unkaos.oboz.tech/'
      };
